from django.apps import AppConfig


class Mm1Config(AppConfig):
    name = 'mm1'
